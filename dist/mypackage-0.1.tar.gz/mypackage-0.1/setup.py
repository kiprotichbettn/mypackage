from setuptools import setup, find_packages

setup(
    name='mypackage',
    version='0.1',
    packages=find_packages(exclude=['tests*']),
    license='MIT',
    description='My test python package',
    long_description=open('README.md').read(),
    install_requires=['numpy'],
    url='https://github.com/kiprotichbettn/mypackage',
    author='Nickson Bett',
    author_email='kiprotichbettn@gmail.com'
)